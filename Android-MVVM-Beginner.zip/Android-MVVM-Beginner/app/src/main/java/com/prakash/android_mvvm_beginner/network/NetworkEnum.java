package com.prakash.android_mvvm_beginner.network;

public enum NetworkEnum {
    GET,POST
}
