package com.prakash.android_mvvm_beginner.model;

public class CommonRequestModel {
    private String appID;
    private String userId;

    public CommonRequestModel(String appID, String userId) {
        this.appID = appID;
        this.userId = userId;
    }
}
