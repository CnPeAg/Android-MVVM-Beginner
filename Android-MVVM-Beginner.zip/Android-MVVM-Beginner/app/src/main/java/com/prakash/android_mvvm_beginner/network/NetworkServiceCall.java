package com.prakash.android_mvvm_beginner.network;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NetworkServiceCall {

}
