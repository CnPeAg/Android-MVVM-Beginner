package com.prakash.android_mvvm_beginner;

import android.app.Application;

public class NirogApplication extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
    }
}
